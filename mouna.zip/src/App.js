import Chart, {
  CommonSeriesSettings,
  ValueAxis,
  Label,
  Legend,
  Series,
  Tooltip,
  Margin, Export,
  CommonAnnotationSettings,
  Annotation
} from 'devextreme-react/chart';
import React, { useEffect, useState } from "react";
import Papa from "papaparse";
import AnnotationTemplate from './AnnotationTemplate.js';
import img from './img/tn_ni-flag.gif'

function App() {
  const [parsedData, setParsedData] = useState([]);
  const [dataSource, setDataSource] = useState([{}]);
  //State tdataSourceo store table Column name
  const [tableRows, setTableRows] = useState([]);
  const [selectedOption, setSelectedOption] = useState(4)
  //State to store the values
  const [values, setValues] = useState([]);
  const [txt, settxt] = useState('Called country');

  const changeHandler = (event) => {
    // Passing file data (event.target.files[0]) to parse using Papa.parse
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {
        const rowsArray = [];
        const valuesArray = [];

        // Iterating data to get column name and their values
        results.data.map((d) => {
          rowsArray.push(Object.keys(d));
          valuesArray.push(Object.values(d));
        });

        // Parsed Data Response in array format
        setParsedData(results.data);
        // setDataSource(results.data)
        // Filtered Column Names
        setTableRows(rowsArray[0]);

        // Filtered Values
        setValues(valuesArray);
      },
    });
  };

  useEffect(() => {
    if (selectedOption === "0") {
      settxt("Please select")
    }
    if (selectedOption === "1") {
      settxt("Called country")
    }
    if (selectedOption === "2") {
      settxt("Call attempts")
    }
    if (selectedOption === "3") {
      settxt("NER (%)")
    }
    if (selectedOption === "4") {
      settxt("ASR (%)")
    }
    if (selectedOption === "5") {
      settxt("Call establishment time avg (s)")
    }
    if (selectedOption === "6") {
      settxt("RTP MOS CQ avg")
    }
    if (selectedOption === "7") {
      settxt("Conv time (min)")
    }
    if (selectedOption === "8") {
      settxt("Conv time avg (s)")
    }
    if (selectedOption === "9") {
      settxt("Call answers")
    }
    let data = []
    if (values) {

      values.map((value, index) =>
        data.push({ "txt": `<img src=${img} alt="Logo" />${value[1]}`, "color": 'blue', "value": Number(value[selectedOption]) }),
      )

    }

    setDataSource(data)
    console.log(data)
  }, [selectedOption]);
  // const  = {}


  const customizeTooltip = (e) => {
    return { text: Math.abs(e.valueText) };
  }

  const customizePoint = (arg) => {
    if (arg.value > 10) {
      return { color: '#ff7c7c', hoverStyle: { color: '#ff7c7c' } };
    }
    if (arg.value < 10) {
      return { color: '#8c8cff', hoverStyle: { color: '#8c8cff' } };
    }
    return null;
  }

  const customizeLabel = (arg) => {
    if (arg.value > 10) {
      return {
        visible: true,
        backgroundColor: '#ff7c7c',
        customizeText(e) {
          return `${e.valueText}`;
        },
      };

    }
    if (arg.value < 10) {
      return {
        visible: true,
        backgroundColor: '#8c8cff',
        customizeText(e) {
          return `${e.valueText}`;
        },
      };
    }

  }

  const customizeText = (arg) => {
    return `${arg.valueText}`;
  }


  return (
    <div>

      <input
        type="file"
        name="file"
        onChange={changeHandler}
        accept=".csv"
        style={{ display: "block", margin: "10px auto" }}
      />
      <select name="type" onChange={(e) => setSelectedOption(e.target.value)}>
        <option value={0}>Please Select</option>
        <option value={2}>Call attempts</option>
        <option value={3}>NER (%)</option>
        <option value={4}>ASR (%)</option>
        <option value={5}>Call establishment time avg (s)</option>
        <option value={6}>RTP MOS CQ avg</option>
        <option value={7}>Conv time (min)</option>
        <option value={8}>Conv time avg (s)</option>
        <option value={9}>Call answers</option>
      </select>
      <Chart
        title={txt}
        dataSource={dataSource}
        id="chart"
        rotated={true}
        barGroupWidth={18}
        customizePoint={customizePoint}
        customizeLabel={customizeLabel}

      >
        <CommonSeriesSettings
          type="stackedbar"
          argumentField="txt"
        />
        <Series
          valueField="value"
          name={txt}
          color="#3F7FBF"
        />
        <CommonAnnotationSettings
          type="custom"
          series="Population"
          render={AnnotationTemplate}
          allowDragging={true}
        >
        </CommonAnnotationSettings>
        {dataSource && dataSource.map((data) => (
          <Annotation
            argument={data.name}
            key={data.name}
            data={data}
          >
          </Annotation>

        ))}
        <Legend visible={false}></Legend>


        <Export enabled={true} />
      </Chart>
    </div>
  )



}

export default App;