import React from 'react';

function getImagePath(data) {
  return `img/tn_ni-flag.gif`;
}

const formatNumber = new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 0,
}).format;

export default function AnnotationTemplate(annotation) {
  const { data } = annotation;
  return (
    <svg className="annotation">
      <image href={getImagePath(data)} width="60" height="40" />
    </svg>
  );
}
