import Chart, {
  CommonSeriesSettings,
  ValueAxis,
  Label,
  Legend,
  Series,
  Tooltip,
  Margin, Export,
  CommonAnnotationSettings,
  Annotation,
  Aggregation,
  Image
} from 'devextreme-react/chart';
import React, { useEffect, useState } from "react";
import Papa from "papaparse";
import AnnotationTemplate from './AnnotationTemplate.js';
// import img from './img/Nigeria.png'
import { Progress } from 'reactstrap';

function App() {
  const [parsedData, setParsedData] = useState([]);
  const [dataSource, setDataSource] = useState([{}]);
  //State tdataSourceo store table Column name
  const [tableRows, setTableRows] = useState([]);
  const [selectedOption, setSelectedOption] = useState(4)
  //State to store the values
  const [values, setValues] = useState([]);
  const [txt, settxt] = useState('Called country');
  const [limit, setLimit] = useState(10);
  const [max, setMax] = useState(10);

  const changeHandler = (event) => {
    // Passing file data (event.target.files[0]) to parse using Papa.parse
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {
        const rowsArray = [];
        const valuesArray = [];

        // Iterating data to get column name and their values
        results.data.map((d) => {
          rowsArray.push(Object.keys(d));
          valuesArray.push(Object.values(d));
        });

        // Parsed Data Response in array format
        setParsedData(results.data);
        // setDataSource(results.data)
        // Filtered Column Names
        setTableRows(rowsArray[0]);
        // Filtered Values
        setValues(valuesArray);
      },
    });
  };

  useEffect(() => {
    if (selectedOption === "0") {
      settxt("Please select")
      
    }
    if (selectedOption === "1") {
      setLimit(10)
      settxt("Called country")
    }
    if (selectedOption === "2") {
      setLimit(5)
      settxt("Call attempts")
    }
    if (selectedOption === "3") {
      setLimit(30)
      settxt("NER (%)")
    }
    if (selectedOption === "4") {
      setLimit(20)
      settxt("ASR (%)")
    }
    if (selectedOption === "5") {
      setLimit(3)
      settxt("Call establishment time avg (s)")
    }
    if (selectedOption === "6") {
      setLimit(4)
      settxt("RTP MOS CQ avg")
    }
    if (selectedOption === "7") {
      setLimit(5)
      settxt("Conv time (min)")
    }
    if (selectedOption === "8") {
      setLimit(3)
      settxt("Conv time avg (s)")
    }
    if (selectedOption === "9") {
      setLimit(2)
      settxt("Call answers")
    }
    let data = []
    if (values) {

      values.map((value, index) =>
        data.push({ "txt": `${value[1]}`, "color": 'blue', "value": Number(value[selectedOption]) }),
      )

    }

    setDataSource(data)
    setMax(Math.max(...data.map(member => member.value)))
    console.log(data)
  }, [selectedOption]);
  // const  = {}


  const customizeTooltip = (e) => {
    return { text: Math.abs(e.valueText) };
  }

  const customizePoint = (arg) => {
    if (arg.value > limit) {
      return { color: '#ff7c7c', hoverStyle: { color: '#ff7c7c' } };
    }
    if (arg.value < limit) {
      return { color: '#8c8cff', hoverStyle: { color: '#8c8cff' } };
    }
    return null;
  }

  const customizeLabel = (arg) => {
    if (arg.value > limit) {
      return {
        visible: true,
        backgroundColor: '#ff7c7c',
        customizeText(e) {
          return `${e.valueText}`;
        },
      };

    }
    if (arg.value < limit) {
      return {
        visible: true,
        backgroundColor: '#8c8cff',
        customizeText(e) {
          return `${e.valueText}`;
        },
      };
    }

  }

  const customizeText = (arg) => {
    return `${arg.valueText}`;
  }


  return (
    <div>
      <input
        type="file"
        name="file"
        onChange={changeHandler}
        accept=".csv"
        style={{ display: "block", margin: "10px auto" }}
      />
      <select name="type" onChange={(e) => setSelectedOption(e.target.value)}>
        <option value={0}>Please Select</option>
        <option value={2}>Call attempts</option>
        <option value={3}>NER (%)</option>
        <option value={4}>ASR (%)</option>
        <option value={5}>Call establishment time avg (s)</option>
        <option value={6}>RTP MOS CQ avg</option>
        <option value={7}>Conv time (min)</option>
        <option value={8}>Conv time avg (s)</option>
        <option value={9}>Call answers</option>
      </select>
      {/* <Chart
        title={txt}
        dataSource={dataSource}
        id="chart"
        rotated={true}
        barGroupWidth={18}
        customizePoint={customizePoint}
        customizeLabel={customizeLabel}

      >
        <CommonSeriesSettings
          type="bar"
          argumentField="txt"
        >
          <Aggregation enabled={false} />
        </CommonSeriesSettings>
        <Series
          valueField="value"
          name={txt}
          color="#3F7FBF"
        />
        <CommonAnnotationSettings
          type="custom"
          series="Population"
          render={AnnotationTemplate}
          allowDragging={true}
        >
          <Image width={10.5} height={10.75} />
        </CommonAnnotationSettings>
        {console.log(dataSource)}
        {dataSource && dataSource.map((item) => <Annotation
          key={item.description}
          argument={item.date}
          type="image"
          text={item.txt}
          >
          <Image url={img} />
        </Annotation>)}
        <Legend visible={false}></Legend>


        <Export enabled={true} />
      </Chart> */}
      <div className='container'>
        {dataSource && dataSource.map((item) => {
          let flag = "./img/" + item.txt + ".png";
          let val = (parseInt(item.value) * 100) / parseInt(max);
          return (<div className='spaceFlex'>
            <div className='title'>{item.txt} <img src={flag} alt="Logo" /> </div>
            <div class="progress">
              {}
              <div class={item.value > limit ? 'progress-bar bg-info' : ' progress-bar bg-danger'} role="progressbar" style={{ width: val+'%' }} aria-valuenow={item.value} aria-valuemin="0" aria-valuemax={max}>
                <label>{item.value}</label></div>
            </div>
          </div>)
        })}
      </div>
    </div>
  )



}

export default App;