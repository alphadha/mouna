import "./App.css";
import React, { useEffect, useState } from "react";
import Papa from "papaparse";
import { Chart } from "react-google-charts";
import randomColor from "randomcolor";
function App() {
  // State to store parsed data
  const [parsedData, setParsedData] = useState([]);

  //State to store table Column name
  const [tableRows, setTableRows] = useState([]);
  const [selectedOption, setSelectedOption] = useState(4)
  //State to store the values
  const [values, setValues] = useState([]);
  const [txt, settxt] = useState('Called country');

  const changeHandler = (event) => {
    // Passing file data (event.target.files[0]) to parse using Papa.parse
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {
        const rowsArray = [];
        const valuesArray = [];

        // Iterating data to get column name and their values
        results.data.map((d) => {
          rowsArray.push(Object.keys(d));
          valuesArray.push(Object.values(d));
        });

        // Parsed Data Response in array format
        setParsedData(results.data);
        console.log(results.data)
        // Filtered Column Names
        setTableRows(rowsArray[0]);

        // Filtered Values
        setValues(valuesArray);
      },
    });
  };
  let data = []
  // let color = randomColor()
  let color = '#a5a5e9'
  if (tableRows) {
    data.push(['', txt, { role: 'style' }, { role: 'annotation' }])
    values?.map((value, index) =>
      // value.filter((key, index) => index !== 0)
      data.push([value[1], Number(value[selectedOption]), color, Number(value[selectedOption])]),
    )
    console.log(data)
  }
  useEffect(() => {
    if (selectedOption === "1") {
      settxt("Called country")
    }
    if (selectedOption === "2") {
      settxt("Call attempts")
    }
    if (selectedOption === "3") {
      settxt("NER (%)")
    }
    if (selectedOption === "4") {
      settxt("ASR (%)")
    }
    if (selectedOption === "5") {
      settxt("Call establishment time avg (s)")
    }
    if (selectedOption === "6") {
      settxt("RTP MOS CQ avg")
    }
    if (selectedOption === "7") {
      settxt("Conv time (min)")
    }
    if (selectedOption === "8") {
      settxt("Conv time avg (s)")
    }
    if (selectedOption === "9") {
      settxt("Call answers")
    }

  }, [selectedOption]);

  const options = {
    title: "Statistique",
    chartArea: { width: "50%" },
    hAxis: {
      title: "Total " + txt,
      minValue: 0,
      format: '# ###.##'
    },
    vAxis: {format: 'short'},


    legend_toggle: true,
    legendToggle: true,
    role: 'annotations',
    format: '# ###.##'
  };

  return (
    <div>
      {/* File Uploader */}
      <input
        type="file"
        name="file"
        onChange={changeHandler}
        accept=".csv"
        style={{ display: "block", margin: "10px auto" }}
      />
      <select name="type" onChange={(e) => setSelectedOption(e.target.value)}>
        <option value={1}>Called country</option>
        <option value={2}>Call attempts</option>
        <option value={3}>NER (%)</option>
        <option value={4}>ASR (%)</option>
        <option value={5}>Call establishment time avg (s)</option>
        <option value={6}>RTP MOS CQ avg</option>
        <option value={7}>Conv time (min)</option>
        <option value={8}>Conv time avg (s)</option>
        <option value={9}>Call answers</option>
      </select>
      <br />
      <br />
      {/* Table */}
      {/* <table>
        <thead>
          <tr>
            {tableRows.map((rows, index) => {
              return <th key={index}>{rows}</th>;
            })}
          </tr>
        </thead>
        <tbody>
          {values.map((value, index) => {
            return (
              <tr key={index}>
                {value.map((val, i) => {
                  return <td key={i}>{val}</td>;
                })}
              </tr>
            );
          })}
        </tbody>
      </table> */}
      {values && values ?
        <Chart
          chartType="BarChart"
          width="100%"
          height="100vh"
          data={data}
          options={options}
        />
        : ''}
    </div>
  );
}

export default App;
